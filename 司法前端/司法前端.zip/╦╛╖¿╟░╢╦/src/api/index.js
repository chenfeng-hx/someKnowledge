import * as analysisDocx from './analysisDocx'
import * as search from './search'
export default {
    analysisDocx,
    search
}
